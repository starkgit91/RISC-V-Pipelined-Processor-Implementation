# Implementation evidence and next checkpoint

The overall objective remains incomplete. Completion requires the processor, AXI system,
firmware, documentation, and the agreed verification/build deliverables.

| Block | Deliverable | Current state |
|---|---|---|
| 1 | Configuration, instruction definitions, physical tags, queue records | Implemented; Icarus declaration tests pass |
| 2 | Decoder, immediate generator, ALU, shifts, comparisons | Implemented; Icarus combinational tests pass |
| 3 | Physical register file and bypass | Implemented; Icarus clocked tests pass |
| 4 | Rename maps, free list, readiness | Awaiting user learning checkpoint |
| 5 | Reorder buffer and retirement | Not implemented |
| 6 | Issue queue and oldest-ready scheduling | Not implemented |
| 7 | Independent integer and iterative multiply/divide execution | Not implemented |
| 8 | Completion arbitration and speculative writeback | Not implemented |
| 9 | Fetch unit and synchronous BRAM adapter | Not implemented |
| 10 | BTB/PHT predictor | Not implemented |
| 11 | Misprediction recovery and cancellation | Not implemented |
| 12 | Ordered memory queue and LSU | Not implemented |
| 13 | CSRs, exceptions, interrupts, system instructions | Not implemented |
| 14 | AXI4-Lite master and machine timer | Not implemented |
| 15 | Complete processor integration and OoO demonstrations | Not implemented |
| 16 | Vivado block design, FPGA wrapper, constraints | Not implemented |
| 17 | Firmware, architectural tests, implementation and bitstream flow | Not implemented |

## Current evidence

Block 1's compilation and tests cover configuration dimensions, ROB identity representation,
record transport, physical-destination metadata, exception metadata, and memory request fields.
They do not simulate instruction execution, allocation, scheduling, recovery, AXI, or interrupts.
See `reports/block01_results.json` for source hashes and the exact check count.

Block 2's compilation and tests cover encoding legality, immediate generation, source-use flags,
integer ALU results, and branch conditions. The testbench covers all R-type selector combinations,
all signed 12-bit I/S immediates, shift restrictions, edge/random operands, and other directed cases.
It does not implement or test the full execution wrapper, renaming, retirement, memory effects,
CSR side effects, or trap entry. See `reports/block02_results.json` for exact evidence and scope.

Block 3's clocked tests cover physical value storage, asynchronous reset, two independent read
ports, accepted-completion bypass, p0 protection, and persistence only at enabled write edges.
They use an independent reference array and include all 64 x 64 read-address pairs, walking data
bits, and 1,024 deterministic random cycles. They do not validate readiness, rename allocation,
ROB ownership checks, completion arbitration, or architectural commitment. Exact evidence is in
`reports/block03_results.json`; an optional VCD is generated with the runner's `--waves` option.

Vivado is not installed in this workspace. Its compilation, synthesis, timing, DRC, and bitstream
results remain unverified until the corresponding Linux flow is actually run.

## Block 4 learning checkpoint

The rename block will map architectural source names to physical identities before replacing
the destination mapping. It will maintain speculative and committed maps, allocate destinations
from a free list, and track readiness. Completion marks a live destination ready; retirement
updates the committed map and releases the replaced physical identity. Source mapping happens
before destination mapping, which matters when an instruction reads and writes the same x register.

The physical register file from block 3 stores the values selected by these identities. The
rename block must not reset those values during branch recovery; it restores the committed map
and rebuilds the free list only after younger work is safely cancelled.

Question before block 4 implementation: start with two instructions writing x5 to explain WAR/WAW
renaming, or with a producer/consumer pair to explain RAW readiness? Both are covered; the answer
sets the explanation order before implementation.
