# Block 10: BTB and bimodal prediction

IF lookup receives two PCs from fetch and returns next-PC, taken, BTB-hit, and PHT-index records. WB retirement supplies a completed prefix; speculative execution cannot train state.

## Circuit and data movement

64 tagged BTB entries store a 24-bit PC tag, target, and conditional flag. 128 two-bit counters start at01. The high counter bit selects taken; updates saturate rather than wrap.

## Cycle example

For T,T,T,N the counter moves01→10→11→11→10. The exit leaves a taken bias. Conditional targets use PC+immediate even when the retired outcome was not taken; caching fall-through would predict the wrong loop target.

## Ordering and interface rules

Lookup enable bypasses prediction without disabling training. Invalidation returns sequential predictions immediately and clears tables at the edge. Two retirements fold in program order, including same-index collisions.

## Verification and waveform reading

Run `python3 scripts/run_checks.py --block 10 --waves`. The source-hashed report records the actual scope and check count. Inspect valid/ready, retained owner metadata, accepted completion, and retirement separately. Passing directed tests does not constitute ISA certification or full-core verification.

## Interview discussion

Why train at retirement? Squashed instructions cannot change predictor state. Why retain tags? Two PCs sharing a BTB index must not use one another's target.
