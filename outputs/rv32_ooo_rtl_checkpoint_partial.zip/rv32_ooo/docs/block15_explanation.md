# Block 15: Assembled core — end-to-end verification pending

This source composes fetch, prediction, dual decode/rename, ROB/IQ, execution, LSU, CSR state, writeback and trace. It is not yet a verified complete processor.

## Circuit and data movement

Native instruction requests return64-bit rows; data requests use32-bit aligned words and byte strobes. IRQ inputs are synchronous to the core clock. halt stops admission while older work can drain.

## Cycle example

System instructions are intercepted from issue port0 into the serialized CSR engine. Five completion sources feed two writeback slots. Memory transactions are restricted to the ROB head.

## Ordering and interface rules

Production trap/IRQ/recovery connections elaborate, but no completed tb_block15 exists at this checkpoint. Required end-to-end tests include wrong-path MMIO suppression, interrupts during long operations, MRET, FENCE.I and architectural trace equivalence.

## Verification and waveform reading

Functional tests remain pending. The source below is included for review, not as a verified deliverable.

## Interview discussion

What does a passing elaboration prove? Port/type/syntax compatibility, not correct instruction execution or precise interrupt boundaries.
