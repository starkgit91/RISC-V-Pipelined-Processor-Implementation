# Block 13: Machine CSRs, traps, and interrupt state

The serialized head system instruction provides decoded CSR controls and source value. The unit returns old CSR data/fault metadata through completion, retains write intent, and mutates architectural state only at matching retirement.

## Circuit and data movement

Machine CSRs are registers with address decode/read muxes and WARL masks. Cycle/retirement counters are64bit. Pending interrupt bits come from external/software/timer inputs; eligibility also checks mie and global mstatus.MIE.

## Cycle example

On trap entry, save aligned mepc, mcause and mtval, copy MIE to MPIE, and clear MIE. Direct mtvec uses its base; vectored interrupts add4×cause. MRET commits the saved interrupt-enable state. WFI waits without gating the clock.

## Ordering and interface rules

All six CSR forms are supported. CSRRS/CSRRC suppress writes only for encoded rs1=x0, even if a nonzero source register contains zero. Read-only/unsupported writes fault. Fixed WARL fields accept writes without changing fixed values.

## Verification and waveform reading

Run `python3 scripts/run_checks.py --block 13 --waves`. The source-hashed report records the actual scope and check count. Inspect valid/ready, retained owner metadata, accepted completion, and retirement separately. Passing directed tests does not constitute ISA certification or full-core verification.

## Interview discussion

Why defer writes until retirement? A fault or recovery must not expose speculative CSR state. What is IRQ priority? External, then software, then timer. Full-core drain/entry composition remains unverified.
