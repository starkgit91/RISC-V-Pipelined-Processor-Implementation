# Block 14: AXI4-Lite transport and machine timer

The master receives one word-aligned core request and returns a retained data/error response. The timer is a separate AXI-Lite slave; connecting an entire processor/fabric is not yet tested.

## Circuit and data movement

AW and W have independent pending state. Either can transfer first; accepted address/data remain owned until B completes. AR and R similarly retain one read. Non-OKAY responses become core errors.

## Cycle example

If AW is accepted while W stalls, AWVALID drops while WVALID/data/strobes hold. The store remains incomplete until BVALID/BREADY. CPU response backpressure cannot overwrite that final response.

## Ordering and interface rules

Timer offsets: MSIP0, mtimecmp4000/4004, mtimebff8/bffc. Byte strobes update selected bytes; mtime is64bit and increments each cycle. IRQ asserts at mtime>=mtimecmp. Invalid offsets/alignment return SLVERR with no write.

## Verification and waveform reading

Run `python3 scripts/run_checks.py --block 14 --waves`. The source-hashed report records the actual scope and check count. Inspect valid/ready, retained owner metadata, accepted completion, and retirement separately. Passing directed tests does not constitute ISA certification or full-core verification.

## Interview discussion

Why cannot AW and W be treated as one handshake? AXI permits independent channel backpressure. Why wait for B? Address/data acceptance is not write completion.
