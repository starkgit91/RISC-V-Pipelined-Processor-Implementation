# Block 11: Recovery controller — integration not verified

This source is an implementation draft. Elaboration passes; dedicated controller/full-core functional validation is pending.

## Circuit and data movement

RUN captures one target and enters CANCEL. Cancellation remains asserted until all producer acknowledgments and quiescence agree. APPLY pulses queue/map flush and fetch redirect, then returns to RUN.

## Cycle example

A delayed cancellation acknowledgment keeps APPLY low and the target stable. Resource reuse must occur only after running operations and completion buffers are empty.

## Ordering and interface rules

The assembled core connects this controller, but that composition has not been simulated successfully yet. Do not treat elaboration as functional verification.

## Verification and waveform reading

Functional tests remain pending. The source below is included for review, not as a verified deliverable.

## Interview discussion

Why is a tag generation insufficient? An old result can arrive after reuse unless producers are actually cancelled/drained.
