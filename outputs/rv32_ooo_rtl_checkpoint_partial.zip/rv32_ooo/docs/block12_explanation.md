# Block 12: Ordered load/store queue

Dispatch allocates up to two memory entries. Integer EX supplies prepared byte addresses/store values. Only the prepared oldest entry matching the live incomplete ROB head may issue a data request.

## Circuit and data movement

Four queue records retain full ownership. IDLE→REQUEST→RESPONSE→COMPLETE controls one transaction. Requests remain stable until accepted; stores complete after their response. The completion is held until writeback accepts it.

## Cycle example

A byte store at address3 shifts its raw value by24bits and selects strobe1000 at aligned bus address0. A signed byte load selects that lane then extends bit7. Halfword/word misalignment completes with a fault and no bus request.

## Ordering and interface rules

Bus errors become load/store access faults with the original byte address. Idle recovery clears unissued entries; an active transaction cannot be erased by flush. Queue capacity uses current free entries.

## Verification and waveform reading

Run `python3 scripts/run_checks.py --block 12 --waves`. The source-hashed report records the actual scope and check count. Inspect valid/ready, retained owner metadata, accepted completion, and retirement separately. Passing directed tests does not constitute ISA certification or full-core verification.

## Interview discussion

Why wait for the ROB head? MMIO reads and stores can have irreversible side effects. Does early address calculation violate ordering? It has no bus side effect.
