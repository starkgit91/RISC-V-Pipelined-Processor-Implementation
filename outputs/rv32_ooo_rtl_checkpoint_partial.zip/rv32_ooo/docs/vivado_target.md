# Retained Vivado target specifications

| Item | Target |
|---|---|
| Tool | Vivado2026.1, Linux |
| FPGA | Artix-7 xc7a35tcpg236-1 |
| Reference board | Basys3 |
| Reference clock |100MHz |
| Core/AXI clock target |50MHz |
| RTL |Synthesizable SystemVerilog |
| RAM |64KiB shared native dual-port; data32bits, fetch64bits |
| Native instruction latency |One synchronous read stage; additional output registers disabled |

Firmware and FPGA/IP integration were removed from scope by the user. No block design, clock/reset IP project, constraints, synthesis, timing, DRC or bitstream result is delivered. The external system must supply the core clock/reset, synchronous IRQs and memory/bus endpoints. The native adapter permits a write-collision hold. AXI UART/GPIO/fabric integration is not included. The50MHz figure is a target, not a measured implementation result.
