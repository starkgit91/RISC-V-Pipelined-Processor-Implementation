# Implementation evidence and next checkpoint

The overall objective remains incomplete. Completion requires the processor, AXI system,
firmware, documentation, and the agreed verification/build deliverables.

## Current architecture decision

The user selected two-issue after the architecture discussion. Blocks 1–6 now use the revised
interfaces for two-wide dispatch, issue, completion, and retirement; fetch remains a future block. The active register file now
has four read ports and two write ports; two-wide renaming and the ROB are tested as well.
The verified single-issue checkpoint is preserved under reference/single_issue. Reports from
that checkpoint do not prove the revised interfaces; current tests must be rerun after revision.

Block 5's provisional single-issue ROB/trace-recorder drafts are saved outside active RTL.
The active two-wide ROB/trace revision and connected control/storage test pass Icarus. The user's
chosen teaching example remains an older DIV and a younger ADD completing first.

| Block | Deliverable | Current state |
|---|---|---|
| 1 | Configuration, instruction definitions, physical tags, queue records | Implemented; Icarus declaration tests pass |
| 2 | Decoder, immediate generator, ALU, shifts, comparisons | Implemented; Icarus combinational tests pass |
| 3 | Physical register file and bypass | Four-read/two-write revision tests pass |
| 4 | Rename maps, free list, readiness | Two-wide revision tests pass |
| 5 | Reorder buffer and retirement | Two-wide unit and connected control/storage tests pass |
| 6 | Issue queue and oldest-ready scheduling | Two-issue unit and connected scheduling tests pass |
| 7 | Independent integer and iterative multiply/divide execution | Not implemented |
| 8 | Completion arbitration and speculative writeback | Not implemented |
| 9 | Fetch unit and synchronous BRAM adapter | Not implemented |
| 10 | BTB/PHT predictor | Not implemented |
| 11 | Misprediction recovery and cancellation | Not implemented |
| 12 | Ordered memory queue and LSU | Not implemented |
| 13 | CSRs, exceptions, interrupts, system instructions | Not implemented |
| 14 | AXI4-Lite master and machine timer | Not implemented |
| 15 | Complete processor integration and OoO demonstrations | Not implemented |
| 16 | Vivado block design, FPGA wrapper, constraints | Not implemented |
| 17 | Firmware, architectural tests, implementation and bitstream flow | Not implemented |

## Current evidence

Block 1's compilation and tests cover configuration dimensions, ROB identity representation,
record transport, physical-destination metadata, exception metadata, and memory request fields.
They do not simulate instruction execution, allocation, scheduling, recovery, AXI, or interrupts.
See `reports/block01_results.json` for source hashes and the exact check count.

Block 2's compilation and tests cover encoding legality, immediate generation, source-use flags,
integer ALU results, and branch conditions. The testbench covers all R-type selector combinations,
all signed 12-bit I/S immediates, shift restrictions, edge/random operands, and other directed cases.
It does not implement or test the full execution wrapper, renaming, retirement, memory effects,
CSR side effects, or trap entry. See `reports/block02_results.json` for exact evidence and scope.

Block 3's clocked tests cover physical value storage, asynchronous reset, four independent read
ports, two writes, dual completion bypass, p0 protection, and enabled-edge persistence.
They use an independent reference array and include all write-address pairs, read-port combinations,
conflict diagnostics, and randomized legal cycles. They do not validate readiness, rename allocation,
ROB ownership checks, completion arbitration, or architectural commitment. Exact evidence is in
`reports/block03_results.json`; an optional VCD is generated with the runner's `--waves` option.

Block 4 checks paired speculative/committed maps, physical allocation, readiness, completion bypass,
dual ordered retirement supplied by the testbench, and recovery application. It includes
within-pair dependencies, prefix/compaction, concurrency, unit exhaustion, and mixed traffic against
an independent reference. It does not implement the ROB, scheduler, completion ownership checks,
or the execution-cancellation barrier. See `reports/block04_results.json` for exact evidence.

Block 5 checks two-wide dispatch/completion/retirement, ownership/generation rejection, precise
fault prefixes, serialization, recovery locking, safe apply, and ordered trace registration.
An additional connected test couples rename, ROB, physical registers, and trace with injected
completion values. It verifies atomic pair handshakes and accepted-versus-stale write gating.
Actual execution units, cancellation, memory transactions, and CSR updates remain
unimplemented. `reports/block05_results.json` lists the two test cases and their source hashes.

Vivado is not installed in this workspace. Its compilation, synthesis, timing, DRC, and bitstream
results remain unverified until the corresponding Linux flow is actually run.

Block 6 checks the eight-entry queue, two-port oldest-ready matching, source readiness,
accepted dual-completion wakeup, operand capture, current-capacity prefix admission, resource
availability, wraparound, system-head restrictions, misprediction filtering, and safe clear.
The standalone selection oracle enumerates legal assignments independently of the RTL's greedy
matching. Its 34,054 checks and the connected test's 43 checks pass: 34,097 total. The connected
case includes rename, ROB, PRF, IQ, and trace, with simulated execution sinks and injected values.
It demonstrates out-of-order issue and in-order retirement, not real DIV execution.
See reports/block06_results.json for exact source hashes and scope.

## Block 7 learning checkpoint

Block 6's chosen teaching example is implemented: younger ready work bypasses an older operand
wait. The next block receives issue packets and PRF values, executes integer/control/address
operations on port 0 and integer operations on port 1, and provides an independent iterative
multiply/divide engine through port 1. Completed results must remain buffered until accepted.
Availability must guarantee issue-edge capture. Cancellation must acknowledge that executing
owners and result buffers are quiescent before recovery permits resource reuse.

Question before block 7 implementation: start with an independent ADD finishing while an older
DIV runs, or first trace the divider's shift/subtract circuit through its iterations? Both are
covered; the answer selects the leading worked example. No block 7 RTL is written yet.
