# Custom RV32 out-of-order learning project

This project is being implemented sequentially, with a user learning checkpoint before each block.
The intended final processor is RV32IM_Zicsr_Zifencei, organized as five logical sections:
IF, ID/rename, EX/scheduling, MEM, and WB/commit.

**Current state: blocks 1 and 2 are implemented.** These include shared definitions, an
RV32IM/system instruction decoder, an integer ALU, and a branch comparator. This is not yet a
working processor. Physical registers, execution engines/buffers, rename allocation, scheduling,
ROB control, AXI, Vivado integration, firmware, and bitstream generation remain to be implemented.

## Read and run block 2

Start with `docs/block02_complete_guide.md`. It follows register ADD from instruction bits
through decoded source names and ALU input values, explains the future rename connection, and
includes the complete decoder, ALU, branch comparator, and testbench source.

```sh
python3 scripts/run_checks.py --block all
python3 scripts/build_guide.py
```

Use `--block 2` for just the decoder/datapath tests. The block-2 tests cover exhaustive R-type
selector and shift-upper-field legality, all signed 12-bit I/S immediates, branch/jump boundaries,
CSR/system/fence forms, x0 behavior, fetch-fault priority, ALU edge/random cases, and branches.
See `reports/block02_results.json` and `reports/block02_simulation.log` for exact evidence.

M instructions and system instructions are recognized but do not execute here. CSR permissions,
memory effects, traps, branch targets/link writeback, and OoO behavior belong to later blocks.

For the same tests in Vivado's XSim on Linux, compile the package before the other files:

```sh
xvlog --sv rtl/rv32_ooo_pkg.sv rtl/rv32_decoder.sv rtl/rv32_alu.sv rtl/rv32_branch_compare.sv tb/tb_block02.sv
xelab tb_block02 -s block02_sim
xsim block02_sim --runall
```

These Vivado commands are provided for your run; they have not been executed in this workspace.

## Read and run block 1

- Start with `docs/block01_complete_guide.md`: explanation, signal map, worked example,
  interview questions, and the complete package/testbench source.
- `rtl/rv32_ooo_pkg.sv` is the source of the shared types and constants.
- `tb/tb_block01.sv` verifies configuration and record representation, not processor behavior.
- `reports/block01_results.json` and `reports/block01_simulation.log` record the latest checks.
- `STATUS.md` tracks the full implementation sequence and the current checkpoint.

From this project directory, with Python 3 and Icarus Verilog available:

```sh
python3 scripts/run_checks.py --block 1
python3 scripts/build_guide.py
```

The runner returns a nonzero exit code on compile failure, simulation failure, or timeout.
No external Python packages are required. A successful record test does not establish ISA or
out-of-order execution correctness; block-2 tests do not establish whole-core correctness.

## Run the same block-1 test in Vivado 2026.1 on Linux

After sourcing your installation's `settings64.sh`, use these commands from this directory:

```sh
xvlog --sv rtl/rv32_ooo_pkg.sv tb/tb_block01.sv
xelab tb_block01 -s block01_sim
xsim block01_sim --runall
```

Expected result: `BLOCK01 SUMMARY` with zero failures. Vivado/XSim execution has not been
verified in this workspace. This test has no clock because it checks declarations, not sequential
hardware. Clocked tests will accompany the actual modules when they are implemented.

## Fixed architecture and FPGA target

| Item | Target |
|---|---|
| ISA | RV32IM_Zicsr_Zifencei, machine mode only |
| Widths | One dispatch, issue, completion broadcast, and retirement per cycle |
| Registers | 32 architectural; 64 physical |
| Queues | 16 ROB, 8 issue, 4 ordered memory, 2 fetch |
| Prediction | 64 BTB, 128 two-bit PHT |
| Memory | 64 KiB shared executable dual-port BRAM |
| FPGA | xc7a35tcpg236-1, Basys-3 reference pinout |
| Tools | Vivado 2026.1 on Linux; portable simulation with Icarus |
| Clock | 100 MHz reference, 50 MHz system target |

Out-of-order execution does not imply out-of-order architectural state changes. Results write
the physical register file on completion; committed mappings advance only at in-order retirement.
Memory requests will be issued only at ROB head. Branch recovery will restore the committed map
after the mispredicting branch retires, cancel younger work, and rebuild the free list.

The 50 MHz target and FPGA fit have not been verified. Actual synthesis, implementation,
constraints, generated IP, firmware initialization, and bitstream checks belong to later blocks.
