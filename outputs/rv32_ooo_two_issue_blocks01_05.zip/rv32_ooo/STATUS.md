# Implementation evidence and next checkpoint

The overall objective remains incomplete. Completion requires the processor, AXI system,
firmware, documentation, and the agreed verification/build deliverables.

## Current architecture decision

The user selected two-issue after the architecture discussion. Revise the existing blocks in
sequence for two-wide fetch/dispatch/issue/completion/retirement. The active register file now
has four read ports and two write ports; two-wide renaming and the ROB are tested as well.
The verified single-issue checkpoint is preserved under reference/single_issue. Reports from
that checkpoint do not prove the revised interfaces; current tests must be rerun after revision.

Block 5's provisional single-issue ROB/trace-recorder drafts are saved outside active RTL.
The active two-wide ROB/trace revision and connected control/storage test pass Icarus. The user's
chosen teaching example remains an older DIV and a younger ADD completing first.

| Block | Deliverable | Current state |
|---|---|---|
| 1 | Configuration, instruction definitions, physical tags, queue records | Implemented; Icarus declaration tests pass |
| 2 | Decoder, immediate generator, ALU, shifts, comparisons | Implemented; Icarus combinational tests pass |
| 3 | Physical register file and bypass | Four-read/two-write revision tests pass |
| 4 | Rename maps, free list, readiness | Two-wide revision tests pass |
| 5 | Reorder buffer and retirement | Two-wide unit and connected control/storage tests pass |
| 6 | Issue queue and oldest-ready scheduling | Awaiting user learning checkpoint |
| 7 | Independent integer and iterative multiply/divide execution | Not implemented |
| 8 | Completion arbitration and speculative writeback | Not implemented |
| 9 | Fetch unit and synchronous BRAM adapter | Not implemented |
| 10 | BTB/PHT predictor | Not implemented |
| 11 | Misprediction recovery and cancellation | Not implemented |
| 12 | Ordered memory queue and LSU | Not implemented |
| 13 | CSRs, exceptions, interrupts, system instructions | Not implemented |
| 14 | AXI4-Lite master and machine timer | Not implemented |
| 15 | Complete processor integration and OoO demonstrations | Not implemented |
| 16 | Vivado block design, FPGA wrapper, constraints | Not implemented |
| 17 | Firmware, architectural tests, implementation and bitstream flow | Not implemented |

## Current evidence

Block 1's compilation and tests cover configuration dimensions, ROB identity representation,
record transport, physical-destination metadata, exception metadata, and memory request fields.
They do not simulate instruction execution, allocation, scheduling, recovery, AXI, or interrupts.
See `reports/block01_results.json` for source hashes and the exact check count.

Block 2's compilation and tests cover encoding legality, immediate generation, source-use flags,
integer ALU results, and branch conditions. The testbench covers all R-type selector combinations,
all signed 12-bit I/S immediates, shift restrictions, edge/random operands, and other directed cases.
It does not implement or test the full execution wrapper, renaming, retirement, memory effects,
CSR side effects, or trap entry. See `reports/block02_results.json` for exact evidence and scope.

Block 3's clocked tests cover physical value storage, asynchronous reset, four independent read
ports, two writes, dual completion bypass, p0 protection, and enabled-edge persistence.
They use an independent reference array and include all write-address pairs, read-port combinations,
conflict diagnostics, and randomized legal cycles. They do not validate readiness, rename allocation,
ROB ownership checks, completion arbitration, or architectural commitment. Exact evidence is in
`reports/block03_results.json`; an optional VCD is generated with the runner's `--waves` option.

Block 4 checks paired speculative/committed maps, physical allocation, readiness, completion bypass,
dual ordered retirement supplied by the testbench, and recovery application. It includes
within-pair dependencies, prefix/compaction, concurrency, unit exhaustion, and mixed traffic against
an independent reference. It does not implement the ROB, scheduler, completion ownership checks,
or the execution-cancellation barrier. See `reports/block04_results.json` for exact evidence.

Block 5 checks two-wide dispatch/completion/retirement, ownership/generation rejection, precise
fault prefixes, serialization, recovery locking, safe apply, and ordered trace registration.
An additional connected test couples rename, ROB, physical registers, and trace with injected
completion values. It verifies atomic pair handshakes and accepted-versus-stale write gating.
Actual execution units, scheduling, cancellation, memory transactions, and CSR updates remain
unimplemented. `reports/block05_results.json` lists the two test cases and their source hashes.

Vivado is not installed in this workspace. Its compilation, synthesis, timing, DRC, and bitstream
results remain unverified until the corresponding Linux flow is actually run.

## Block 6 learning checkpoint

The issue queue will receive renamed pairs, retain their physical source identities/readiness,
and use accepted completion broadcasts to wake dependents. It will choose up to two oldest-ready
instructions compatible with available execution ports, supplying four PRF read tags and removing
only instructions actually accepted by an execution path. An older operand/resource wait must
not block an independent younger eligible instruction. Recovery cancels the queue consistently.

Question before block 6 implementation: begin with choosing two independent ready instructions
for the two execution ports, or with a younger ready instruction bypassing an older operand wait?
Both scenarios are included; the answer sets the first worked example.
