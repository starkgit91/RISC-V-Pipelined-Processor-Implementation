# Implementation evidence and next checkpoint

The overall objective remains incomplete. Completion requires the processor, AXI system,
firmware, documentation, and the agreed verification/build deliverables.

| Block | Deliverable | Current state |
|---|---|---|
| 1 | Configuration, instruction definitions, physical tags, queue records | Implemented; Icarus declaration tests pass |
| 2 | Decoder, immediate generator, ALU, shifts, comparisons | Awaiting user learning checkpoint |
| 3 | Physical register file and bypass | Not implemented |
| 4 | Rename maps, free list, readiness | Not implemented |
| 5 | Reorder buffer and retirement | Not implemented |
| 6 | Issue queue and oldest-ready scheduling | Not implemented |
| 7 | Independent integer and iterative multiply/divide execution | Not implemented |
| 8 | Completion arbitration and speculative writeback | Not implemented |
| 9 | Fetch unit and synchronous BRAM adapter | Not implemented |
| 10 | BTB/PHT predictor | Not implemented |
| 11 | Misprediction recovery and cancellation | Not implemented |
| 12 | Ordered memory queue and LSU | Not implemented |
| 13 | CSRs, exceptions, interrupts, system instructions | Not implemented |
| 14 | AXI4-Lite master and machine timer | Not implemented |
| 15 | Complete processor integration and OoO demonstrations | Not implemented |
| 16 | Vivado block design, FPGA wrapper, constraints | Not implemented |
| 17 | Firmware, architectural tests, implementation and bitstream flow | Not implemented |

## Current evidence

Block 1's compilation and tests cover configuration dimensions, ROB identity representation,
record transport, physical-destination metadata, exception metadata, and memory request fields.
They do not simulate instruction execution, allocation, scheduling, recovery, AXI, or interrupts.
See `reports/block01_results.json` for source hashes and the exact check count.

Vivado is not installed in this workspace. Its compilation, synthesis, timing, DRC, and bitstream
results remain unverified until the corresponding Linux flow is actually run.

## Block 2 learning checkpoint

The decoder will receive a fetched instruction and its PC/prediction/fault information, and emit
the `decoded_uop_t` defined in block 1. The ALU will receive operand values and an operation code,
and emit an arithmetic or comparison result. Neither block commits architectural state.

Proposed behavior: accept an instruction only after checking its complete supported encoding.
Anything unsupported produces an illegal-instruction exception rather than silently executing
ADD. Existing instruction-fetch faults take precedence over decoder faults.

Question to answer before block 2 implementation: would you like to begin the explanation by
tracing ADDI from its instruction bits to the ALU result, or by tracing a dependent register ADD
from source-register fields to renamed operand tags? Both paths are included in the lesson;
your choice determines the explanation order.
