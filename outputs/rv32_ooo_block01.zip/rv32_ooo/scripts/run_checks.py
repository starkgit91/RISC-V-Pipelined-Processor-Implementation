#!/usr/bin/env python3
"""Run checks for implemented blocks; never imply unimplemented hardware was tested."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--block", choices=["1"], default="1")
    args = parser.parse_args()
    for executable in ("iverilog", "vvp"):
        if shutil.which(executable) is None:
            parser.error(f"{executable} is required; use the README's Vivado commands instead.")

    build = ROOT / "build" / f"block{int(args.block):02d}"
    reports = ROOT / "reports"
    build.mkdir(parents=True, exist_ok=True)
    reports.mkdir(parents=True, exist_ok=True)
    sources = ["rtl/rv32_ooo_pkg.sv", "tb/tb_block01.sv"]
    commands = [
        ["iverilog", "-g2012", "-Wall", "-s", "tb_block01", "-o",
         str(build / "tb_block01.vvp"), *sources],
        ["vvp", str(build / "tb_block01.vvp")],
    ]
    log_parts = []
    try:
        for command in commands:
            result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, timeout=30)
            log_parts.append("$ " + " ".join(command) + "\n" + result.stdout + result.stderr)
            if result.returncode:
                raise RuntimeError(f"Command failed with exit code {result.returncode}")
        summary = re.search(r"BLOCK01 SUMMARY: (\d+) checks, (\d+) failures", log_parts[-1])
        if not summary or int(summary.group(2)):
            raise RuntimeError("A passing testbench summary was not found")
        version = subprocess.run(["iverilog", "-V"], text=True, capture_output=True, timeout=10)
        evidence = {
            "block": 1,
            "status": "passed",
            "scope": "configuration constants and packed instruction/queue record contracts",
            "checks": int(summary.group(1)),
            "failures": int(summary.group(2)),
            "simulator": version.stdout.splitlines()[0],
            "sources_sha256": {
                name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources
            },
            "not_verified": [
                "instruction decoding or execution", "renaming or out-of-order scheduling",
                "pipeline, AXI, traps, prediction, or firmware", "Vivado or bitstream generation",
            ],
        }
        (reports / "block01_results.json").write_text(json.dumps(evidence, indent=2) + "\n")
        print(f"Block 1: {summary.group(1)} configuration/record checks passed.")
        print("Scope: declarations only; processor logic and Vivado are not yet verified.")
    except (RuntimeError, subprocess.TimeoutExpired) as exc:
        # Replace any older success report so a failed rerun cannot leave a false green result.
        (reports / "block01_results.json").write_text(
            json.dumps({"block": 1, "status": "failed", "error": str(exc)}, indent=2) + "\n"
        )
        print(f"Block 1 failed: {exc}", file=sys.stderr)
        return 1
    finally:
        (reports / "block01_simulation.log").write_text("\n".join(log_parts))
    return 0


if __name__ == "__main__":
    sys.exit(main())
