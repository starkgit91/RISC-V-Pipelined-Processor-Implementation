#!/usr/bin/env python3
"""Keep the lesson's complete code blocks identical to the compiled source files."""

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
lesson = (ROOT / "docs" / "block01_explanation.md").read_text()
for title, filename in [
    ("Complete shared package", "rtl/rv32_ooo_pkg.sv"),
    ("Complete self-checking testbench", "tb/tb_block01.sv"),
]:
    lesson += f"\n## {title}\n\nSource: `{filename}`.\n\n```systemverilog\n"
    lesson += (ROOT / filename).read_text()
    lesson += "```\n"
(ROOT / "docs" / "block01_complete_guide.md").write_text(lesson)
print("Updated block01_complete_guide.md from the actual RTL and testbench.")
